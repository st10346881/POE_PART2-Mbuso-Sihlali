/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rcSihlaliPrj;

import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
public class AddTask {
    
     public void task(){
         

      boolean loggedIn = false ;
              int numTasks = 1;
              int totalHours = 0;
              
              //Login 
              
                      LogIn log = new LogIn();

              if(!loggedIn){
                  String username =JOptionPane.showInputDialog("Confirm Username:\n1) Username ,must consist of 5 characters containing underscore.");
                  String password = JOptionPane.showInputDialog("Confirm Password:\n2) Password ");
                  if (username.equals("admin")&& password.equals("admin123")){
                      JOptionPane.showMessageDialog(null, "Invalid Username or Password");
                      loggedIn = false;
                  }else if(!loggedIn){
                      JOptionPane.showMessageDialog(null, "Welcome to Easy Kanban");
                      loggedIn = true;
                  }
                  
              }
              //Menu
              while(true){
                  String optionStr = JOptionPane.showInputDialog("Enter an Option:"+"\n1) Add Task"+"\n2) Show Report"+"\n3) Quit");
                  int option = Integer.parseInt(optionStr);
                  if(option ==1){
                      String numTasksStr = JOptionPane.showInputDialog("Enter Number of Tasks:");
                      numTasks = Integer.parseInt(numTasksStr);
                      
                      for(int i=1; i < numTasks;i++){
                          String taskName = JOptionPane.showInputDialog("Enter Task Name:");
                          String taskDescription = "";
                         boolean validDescription = false;
                         while(!validDescription){
                             taskDescription = JOptionPane.showInputDialog("Enter Task Description:");
                             if (taskDescription.length()<=50){
                                 JOptionPane.showMessageDialog(null, "Task Description Successfully Captured!!!");
                                 validDescription = true;
                                 
                             }else{
                                 JOptionPane.showMessageDialog(null, "Enter Task Description with less than 50 Characters:");
                             }
                         }
                         String firstName = JOptionPane.showInputDialog("Enter First Name:");
                         String lastName = JOptionPane.showInputDialog("Enter Last Name:");
                         String developerDetails = firstName + ""+ lastName;
                         String taskDurationStr = JOptionPane.showInputDialog("Enter Task Duration in Hours:");
                         int taskDuration = Integer.parseInt(taskDurationStr);
                         totalHours += taskDuration;
                         String taskID = createTaskID(taskName, i, firstName, lastName);
                         String[] statuses = { "To Do", "Doing", "Done"};
                         String taskStatus = (String)JOptionPane.showInputDialog(null, "Select a Task Status:","Task Status",JOptionPane.QUESTION_MESSAGE,null,statuses,statuses[0]);
                         
                         String taskDetails = printTaskDetails(taskStatus, developerDetails, i, taskName,taskDescription, taskID, taskDuration );
                         JOptionPane.showMessageDialog(null, taskDetails);
                      }
                  }else if (option ==2){
                      JOptionPane.showMessageDialog(null, "Coming Soon");
                  }else if (option == 3){
                      JOptionPane.showMessageDialog(null,"Total hours acros all tasks:"+totalHours);
                      System.exit(0);
                  }else {
                     JOptionPane.showMessageDialog(null, "Invalid Option");
                  }
              }
    }
    public static String createTaskID(String taskName, int taskNumber, String firstName, String lastName){
        String taskId = taskName.substring(0,2).toUpperCase()+ ":" + taskNumber + ":" + lastName.substring(0,3).toUpperCase();
        return taskId ;
                }
    public static String printTaskDetails (String taskStatus, String developerDetails,int taskNumber, String taskName, String taskDescription, String taskID, int taskDuration){
        String taskDetails  = "Task Status:" + taskStatus + "\n Task Number:" + taskNumber + "\nTask Name:" + taskName + "\n Task Description:"+ taskDescription + "\n Task ID:"+ taskID + "\n Task Duration:" + taskDuration + "hours";
        return taskDetails;
  
    }
    }
   

     