/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package rcSihlaliPrj;

/**
 *
 * @author Mbuso_Sihlali_ST10346881
 */
public class POEp1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
        //call in the class where you have created your variables
        Register reg = new Register();
        reg.Register();
        
        LogIn log = new LogIn();
        log.Log();
        
        AddTask task = new AddTask();
        task.task();
       
        
    }
    
}
